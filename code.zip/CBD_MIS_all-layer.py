'''
Create on 
@author: BI
'''
'''
修改目标函数的同时修改下界
换算例：改路径 改机器大小 改零件数 改客户数
'''


from gurobipy import *
import numpy as np
import pandas as pd
import re
import time
import sys
import logging
logging.basicConfig(level=logging.INFO)
import math
from itertools import combinations


# 封装模型函数
def run_model(csv_path, output_file, part_i):

    # ===============================
    # 读取数据 read data
    # ===============================
    # df = pd.read_csv('AM&OS/15parts_11_XXS_machine_M_parts.csv')
    df = pd.read_csv(csv_path)
    with open(output_file, 'a') as f:
        f.write(f'{csv_path} solution========================')


    #  机器加工的相关参数
    time_forming_volume = 0.030864 # 扫描速度
    time_powder_layering = 0.7 # 层构建速度
    setup_time = 2

    # 机器的长宽高
    # S
    # length_machine = 15
    # width_machine = 15
    # height_machine = 32.5
    # M
    length_machine = 17.5
    width_machine = 17.5
    height_machine = 32.5
    # L
    # length_machine = 20
    # width_machine = 20
    # height_machine = 32.5

    # 零件数量
    num_part = len(df)
    part = list(range(0,num_part))

    # batch数量，与part数量保持一致
    # num_batch = num_part
    # batch = list(range(0,num_batch))

    # 零件的长宽高
    length_part = df.length_part.tolist()
    width_part = df.width_part.tolist()
    height_part = df.height_part.tolist()
    volume_part = df.volume_part.tolist()

    id_arr = np.array(part)
    width_arr = np.array(width_part)          
    length_arr = np.array(length_part)
    area_arr = width_arr * length_arr

    # 客户相关参数
    num_customer = 3
    # beta = 1/num_customer
    beta = 1
    customer = list(range(0,num_customer))
    order_part = df.customer.tolist()
    a = np.zeros((num_part, num_customer)) #零件i是否属于客户k
    for i in part:
        for k in customer:
            if order_part[i] == k:
                a[i][k] = 1 

    # ================================================
    # FFDH算法计算batch上界
    # =================================================
    def ffdh_upper_bound(lengths, widths, L, W):
        """
        FFDH 上界计算（将 length 当作层高, width 当作层宽）
        返回值：所需的箱数（批次数上界）
        """
        # 按 “层高” length 降序排列
        rects = sorted(zip(lengths, widths), key=lambda x: x[0], reverse=True)

        bins = []  # 每个 bin 对应一个 batch，里面存若干个 shelf
        for h, w in rects:  # h = length, w = width
            placed = False
            # 尝试放入已有的 batch
            for b in bins:
                # 先在已有的各层(shelf)上试放
                for shelf in b:
                    if shelf['height'] >= h and shelf['remaining_width'] >= w:
                        shelf['remaining_width'] -= w
                        placed = True
                        break
                if placed:
                    break
                # 如果层里放不下，就看能否新开一层
                used_height = sum(s['height'] for s in b)
                if used_height + h <= L and w <= W:
                    b.append({'height': h, 'remaining_width': W - w})
                    placed = True
                    break

            # 如果所有 batch 都放不下，就开新 batch（带第一层）
            if not placed:
                bins.append([{'height': h, 'remaining_width': W - w}])

        return len(bins)

    batch_lb = math.ceil(area_arr[id_arr].sum()/(width_machine*length_machine))
    batch_ub = 0
    temp_k = 0
    lengths = []
    widths = []
    while temp_k < num_customer:
        lengths.clear()
        widths.clear()
        for i in part:
            if a[i][temp_k] == 1:
                widths.append(width_part[i])
                lengths.append(length_part[i])
        batch_ub += ffdh_upper_bound(lengths=lengths, widths=widths, L=length_machine, W=width_machine)
        temp_k += 1

    num_batch = batch_ub
    batch = list(range(0,num_batch))

    
    # =======================================
    # 定义记录求解过程的一系列指标
    # =======================================

    # 记录主问题和子问题的迭代次数
    num_MP_iteration = 0
    num_SP_iteration = 0


    # 记录主问题和子问题的运行时间
    MP_total_time = 0
    SP_total_time = 0
    MP_runtime = 0
    SP_runtime = 0


    # 表示batch中不可行的零件list
    unassigned_subset_list_try = []

    indicator_masterfeasible = 1 # 标志主问题可行
    flag = 1 # 标志是否有子问题不可行，如果所有子问题都feasible，flag=0

    # =================================================
    # 回调函数 callback
    # =================================================
    # 定义回调函数
    def my_callback(model, where):
        # print("Gurobi is running the callback function!")
        # sys.stdout.flush()

        if where == GRB.Callback.MIPSOL:
            # print("MIPSOL: Found an integer solution!")
            # sys.stdout.flush()

            # # 获取当前解
            # solution = model.cbGet(gurobipy.GRB.Callback.MIPSOL_SOL)

            # # 获取变量值
            # z_values = [0 for b in batch]
            # u_values = [[0 for b in batch] for i in part]

            # vars = model.getVars()
            # for i, var in enumerate(vars):
            #     if var.varName.startswith("u"):
            #         u_values[int(var.varName.split("[")[1].split(",")[0])][int(var.varName.split("[")[1].split(",")[1].split("]")[0])] = solution[i]
            #     elif var.varName.startswith("z"):
            #         z_values[int(var.varName.split("[")[1].split("]")[0])] = solution[i]

            nonlocal best_obj
            obj = model.cbGet(GRB.Callback.MIPSOL_OBJ)
            # 只有更优时才继续下面的逻辑
            if obj <= best_obj:
                best_obj = obj
            else:
                return    # 新解并不更好，直接跳过

            # 获取当前整数解
            z_values = model.cbGetSolution(model._z)  # 变量 z
            u_values = model.cbGetSolution(model._u)  # 变量 u
            
            # 获取batch数下界，定义assigned_b记录分配在batch b中的零件有哪些
            batch_lowerbound_cb = int(sum(z_values))

            assigned_b = [[] for b in range(0, batch_lowerbound_cb)] # new assigned_b
            # for b in range(0, batch_lowerbound_cb):
            #     for i in part:
            #         if round(u_values[i,b]) == 1:
            #             assigned_b[b].append(i)
            for (i, b), value in u_values.items():  # 遍历字典
                if round(value) == 1:
                    assigned_b[b].append(i)  # 把零件 i 放到 batch b

            # 记录新的不可行 batch
            new_infeasible_batches = []
            
            # 对每个batch建立子问题
            for b in range(0, batch_lowerbound_cb):
                if len(assigned_b[b]) > 1: # 如果这个batch中零件数量大于1，才需要判断是否可行
                    # 理论上 assigned_b[b] 不可能包含任何 un，但以下代码是保险检查
                    # for un in model._unassigned_subset_list_try:
                    #     if set(un).issubset(set(assigned_b[b])):
                    #         print(f"Batch {b} is infeasible (already known)")
                    #         # break
                    #         return # 直接返回
                            
                    # else:

                    # ====================================================================
                    # 先通过Steinberg‘s Theorem来预判断assigned_b[b]是否可行，是否要计算子问题
                    # ====================================================================
                    idx_arr = np.array(assigned_b[b], dtype=int)
                    max_w = width_arr[idx_arr].max()
                    max_l = length_arr[idx_arr].max()
                    batch_area = area_arr[idx_arr].sum()

                    width_item = max(2*max_w - width_machine, 0)
                    length_item = max(2*max_l - length_machine, 0)
                    if (2*batch_area) <= (width_machine*length_machine - width_item*length_item):
                        # 如果满足，则认为可行，跳过子问题
                        # indicator_sbgfeasible = 1
                        continue

                    subproblem = Model("subproblem")
                    subproblem.setParam('OutputFlag', 0)  # 关闭日志

                    # 定义子问题的决策变量
                    x_each = subproblem.addVars(assigned_b[b], ub=width_machine, vtype=GRB.CONTINUOUS, name='x_each')
                    y_each = subproblem.addVars(assigned_b[b], ub=length_machine, vtype=GRB.CONTINUOUS, name='y_each')
                    left = subproblem.addVars(assigned_b[b], assigned_b[b], vtype=GRB.BINARY, name='left')
                    below = subproblem.addVars(assigned_b[b], assigned_b[b], vtype=GRB.BINARY, name='below')

                    # 定义子问题的目标函数
                    subproblem.setObjective(0, sense=GRB.MINIMIZE)
                    

                    # 添加子问题的约束
                    # x[i] + w[i] <= W，i已经是零件编号了，不用再转换
                    subproblem.addConstrs((x_each[i] + width_part[i] <= width_machine for i in assigned_b[b]), name='3a')
                    # y[i] + l[i] <= L
                    subproblem.addConstrs((y_each[i] + length_part[i] <= length_machine for i in assigned_b[b]), name='3b')
                    # left_ij + left_ji + +below_ij + below_ji >= 1
                    for i in assigned_b[b]:
                        for j in assigned_b[b]:
                            if i != j:
                                subproblem.addConstr((left[i,j] + left[j,i] + below[i,j] + below[j,i] >= 1), name='3c[%d,%d]' %(i,j))
                    # x[i] + w[i] <= x[j] + W(1-left_ij)
                    for i in assigned_b[b]:
                        for j in assigned_b[b]:
                            if i != j:
                                subproblem.addConstr((x_each[i] + width_part[i] <= x_each[j] + width_machine*(1 - left[i,j])), name='3d[%d,%d]' %(i,j))
                    # y[i] + l[i] <= y[j] + L(1-below_ij)
                    for i in assigned_b[b]:
                        for j in assigned_b[b]:
                            if i != j:
                                subproblem.addConstr((y_each[i] + length_part[i] <= y_each[j] + length_machine*(1 - below[i,j])), name='3e[%d,%d]' %(i,j))

                    subproblem.update()
                    subproblem.Params.TimeLimit = 1800

                    subproblem.optimize()

                    nonlocal num_SP_iteration  # 声明修改外层函数的变量
                    nonlocal SP_runtime
                    # nonlocal run_time

                    num_SP_iteration += 1 # 每求解一次子问题，就加1

                    SP_runtime += subproblem.Runtime
                    # run_time += subproblem.Runtime
                    

                    if subproblem.status == GRB.INFEASIBLE:
                        # 如果子问题不可行，则生成一个cut并加入集合
                        # print("Subproblem infeasible for solution.")
                        new_infeasible_batches.append(assigned_b[b])

                        # # 如果这个子问题不可行，那么找这个assigned_b[b]中零件的MIS
                        # assigned_subset_n_2 = list(combinations(assigned_b[b],2))  # 先将零件组合成两两组合的形式
                        # for i in range(len(assigned_subset_n_2)):
                        #     assigned_subset_n_2[i] = list(assigned_subset_n_2[i]) # 把元组换成列表形式
                        
                        # subset_templist = assigned_subset_n_2
                        # infeasible_number_n = [0] * len(assigned_b[b]) # 储存一共有几组subset n   
                        # SP_MIS_ban = [] # 寻找MIS过程中新发现的不可行子集，避免重复                 
                        
                        # for n in range(2, len(assigned_b[b])): # 对于assigned_mb[m][b]中每一个n进行循环,不用对n=N的循环了
                        #     if len(subset_templist) == 0:
                        #         break

                        #     MIS_feasible = [] #存储subset_templist中的可行子集
                        #     for assigned_subset in subset_templist: # subset_templist 表示这个n下的所有subset
                        #         # 判断有n个零件的assigned_subset是否为MIS的超集
                        #         flag_ban = 0
                        #         for ban in SP_MIS_ban:
                        #             if set(assigned_subset)>=set(ban):
                        #                 flag_ban = 1
                        #                 break
                        #         if flag_ban:
                        #             subset_templist.remove(assigned_subset)
                        #             continue

                        #         # ====================================================================
                        #         # 先通过Steinberg‘s Theorem来预判断assigned_subset是否可行，是否要计算子问题
                        #         # ====================================================================
                        #         idx_arr = np.array(assigned_subset, dtype=int)
                        #         max_w = width_arr[idx_arr].max()
                        #         max_l = length_arr[idx_arr].max()
                        #         batch_area = area_arr[idx_arr].sum()

                        #         width_item = max(2*max_w - width_machine, 0)
                        #         length_item = max(2*max_l - length_machine, 0)
                        #         if (2*batch_area) <= (width_machine*length_machine - width_item*length_item):
                        #             # 如果满足，则认为可行，跳过子问题
                        #             # indicator_sbgfeasible = 1
                        #             MIS_feasible.append(assigned_subset)
                        #             continue

                        #         MIS_each = Model('MIS_each')

                        #         # 定义决策变量
                        #         x_each = MIS_each.addVars(assigned_subset, ub=width_machine, vtype=GRB.CONTINUOUS, name='x_each')
                        #         y_each = MIS_each.addVars(assigned_subset, ub=length_machine, vtype=GRB.CONTINUOUS, name='y_each')
                        #         left = MIS_each.addVars(assigned_subset, assigned_subset, vtype=GRB.BINARY, name='left')
                        #         below = MIS_each.addVars(assigned_subset, assigned_subset, vtype=GRB.BINARY, name='below')
                        #         # 这样可以保证变量的索引就是assigned_b[b]中零件的编号，不用再转换

                        #         # 定义目标函数
                        #         MIS_each.setObjective(0, sense=GRB.MINIMIZE)

                        #         # 添加子问题的约束
                        #         # x[i] + w[i] <= W，i已经是零件编号了，不用再转换
                        #         MIS_each.addConstrs((x_each[i] + width_part[i] <= width_machine for i in assigned_subset), name='3a')
                        #         # y[i] + l[i] <= L
                        #         MIS_each.addConstrs((y_each[i] + length_part[i] <= length_machine for i in assigned_subset), name='3b')
                        #         # left_ij + left_ji + +below_ij + below_ji >= 1
                        #         for i in assigned_subset:
                        #             for j in assigned_subset:
                        #                 if i != j:
                        #                     MIS_each.addConstr((left[i,j] + left[j,i] + below[i,j] + below[j,i] >= 1), name='3c[%d,%d]' %(i,j))
                        #         # x[i] + w[i] <= x[j] + W(1-left_ij)
                        #         for i in assigned_subset:
                        #             for j in assigned_subset:
                        #                 if i != j:
                        #                     MIS_each.addConstr((x_each[i] + width_part[i] <= x_each[j] + width_machine*(1 - left[i,j])), name='3d[%d,%d]' %(i,j))
                        #         # y[i] + l[i] <= y[j] + L(1-below_ij)
                        #         for i in assigned_subset:
                        #             for j in assigned_subset:
                        #                 if i != j:
                        #                     MIS_each.addConstr((y_each[i] + length_part[i] <= y_each[j] + length_machine*(1 - below[i,j])), name='3e[%d,%d]' %(i,j))

                        #         # 添加变量和约束后更新模型
                        #         MIS_each.update()

                        #         MIS_each.Params.TimeLimit = 1800
                        #         MIS_each.optimize()

                        #         num_SP_iteration += 1 # 每求解一次子问题，就加1
                        #         SP_runtime += MIS_each.Runtime
                        #         # run_time += MIS_each.Runtime

                        #         if MIS_each.Status == GRB.INFEASIBLE:   # 如果对于这个MP-subset子问题不可行
                        #             print(f'MIS_sub_n={assigned_subset} is infeasible')
                        #             infeasible_number_n[n] += 1 # 在这个n下的子问题不可行的数量加1
                        #             SP_MIS_ban.append(assigned_subset)
                        #             new_infeasible_batches.append(assigned_subset)

                        #         if MIS_each.Status == GRB.OPTIMAL: # 如果对于这个subset子问题可行，循环迭代下一个
                        #             MIS_feasible.append(assigned_subset)
                        #             continue

                        #     if infeasible_number_n[n] == len(subset_templist):
                        #         break

                        #     if n < len(assigned_b[b])-1:
                        #         subset_templist.clear()
                        #         for s in MIS_feasible:
                        #             for i in assigned_b[b]:
                        #                 if i > max(s):
                        #                     s_temp = s+[i]
                        #                     subset_templist.append(s_temp)

                        # else:
                        #     if infeasible_number_n[len(assigned_b[b])-1] == 0:
                        #         new_infeasible_batches.append(assigned_b[b])
            
            if new_infeasible_batches:
                # print(f"Adding new cuts for infeasible batches: {new_infeasible_batches}")
                logging.info(f"Adding new cuts for infeasible batches: {new_infeasible_batches}")
                sys.stdout.flush()
                for subset in new_infeasible_batches:
                    model._unassigned_subset_list_try.append(subset)  # 记录新的不可行 batch
                    for b in batch:
                        lhs = quicksum(model._u[i, b] for i in subset)
                        model.cbLazy(lhs <= len(subset) - 1)  # 添加 cut 约束
            
            # for subset in unassigned_subset_list_try:
            #     for b in batch:
            #         lhs = quicksum(main._u[i,b] for i in subset)
            #         main.cbLazy((lhs <= len(subset) - 1), name='cut_cb[%d]' %b)


    # 定义时间限制
    start_time = time.time()
    max_runtime = 7200 # 定义最大运行时间
    CPU_time = 0
    run_time = 0 # 把CPU_time换成run_time

    # ===============================================
    # 建立主问题模型 construct master problem model
    # ===============================================
    obj_lowerbound = 0
    best_obj = float('inf')
    while indicator_masterfeasible == 1 and flag == 1:
        # current_time = time.time()
        # if float((current_time - start_time)) > max_runtime:
            # CPU_time = max_runtime
            # break
        if run_time > max_runtime:
            run_time = max_runtime
            break

        main = Model('main')

        # 定义决策变量
        z = main.addVars(batch, vtype=GRB.BINARY, name='z')
        u = main.addVars(part, batch, vtype=GRB.BINARY, name='u')
        h = main.addVars(batch, ub=height_machine ,vtype=GRB.CONTINUOUS, name='h')
        C = main.addVars(batch, vtype=GRB.CONTINUOUS, name='C')
        C_makespan = main.addVar(vtype=GRB.CONTINUOUS, name='C_makespan')
        C_spread = main.addVars(customer, vtype=GRB.CONTINUOUS, name='C_spread')
        S_spread = main.addVars(customer, lb=0.0, vtype=GRB.CONTINUOUS, name='S_spread')
        E_spread = main.addVars(customer, vtype=GRB.CONTINUOUS, name='E_spread')
        C_total = main.addVar(vtype=GRB.CONTINUOUS, name='C_total')


        # 定义目标函数
        main.setObjective(C_total, sense=GRB.MINIMIZE)

        # main.setObjective(C_makespan, sense=GRB.MINIMIZE)
        # main.setObjective(C_spread.sum(), sense=GRB.MINIMIZE)


        # 添加主问题的约束
        # no-good cut 
        for subset in unassigned_subset_list_try:
            for b in batch:
                lhs = quicksum(u[i,b] for i in subset)
                main.addConstr((lhs <= len(subset) - 1), name='cut[%d]' %b)



        # 累加b的uib=1, for i
        main.addConstrs((u.sum(i, '*') == 1 for i in part), name='2b')
        # hi * uib <= hb
        main.addConstrs((height_part[i]*u[i,b] <= h[b] for i in part for b in batch), name='2c')
        # 累加i的uib <= M * zb
        main.addConstrs((u.sum('*', b) <= num_part * z[b] for b in batch), name='2d')
        # zb <= 累加i的uib
        main.addConstrs((z[b] <= u.sum('*', b) for b in batch), name='2e')
        # zb+1 <= zb
        main.addConstrs((z[b+1] <= z[b] for b in range(num_batch-1)), name='2f')
        # 累加i的wi*li*uib <= W*L
        main.addConstrs((quicksum(width_part[i]*length_part[i]*u[i,b] for i in part) 
                        <= width_machine*length_machine for b in batch), name='2g')
        # Cb >= Cb-1 + VT*累加i的vi*uib + HT*hb + ST*zb
        main.addConstrs((C[b] >= C[b-1] + time_forming_volume*quicksum(volume_part[i]*u[i,b] for i in part) 
                        + time_powder_layering*h[b] + setup_time*z[b] for b in range(1, num_batch)), name='2h')
        # 初始化C0(可以改成等于吗？)
        main.addConstr((C[0] >= time_forming_volume*quicksum(volume_part[i]*u[i,0] for i in part) 
                        + time_powder_layering*h[0] + setup_time*z[0]), name='2i')
        # Cmax >= Cb
        main.addConstrs((C_makespan >= C[b] for b in batch), name='2j')
        # Sk <= 累加b的Cb*uib*aik
        # main.addConstrs((S_spread[k] <= quicksum(C[b]*u[i,b]*a[i][k] for b in batch) 
        #                 for i in part for k in customer), name='2k')
        main.addConstrs((S_spread[k] <= C[b] + 1000*(1-u[i,b]*a[i][k]) 
                        for i in part for b in batch for k in customer), name='2k')
        # Ek >= 累加b的Cb*uib*aik
        # main.addConstrs((E_spread[k] >= quicksum(C[b]*u[i,b]*a[i][k] for b in batch) 
        #                 for i in part for k in customer), name='2l')
        main.addConstrs((E_spread[k] >= C[b] - 1000*(1-u[i,b]*a[i][k]) 
                        for i in part for b in batch for k in customer), name='2l')
        # Ck = Ek - Sk
        main.addConstrs((C_spread[k] == E_spread[k]-S_spread[k] for k in customer), name='2m')
        # C_total
        main.addConstr((C_total == C_makespan + beta*C_spread.sum()), name='2n')

        main.addConstr((C_total >= obj_lowerbound), name='lb')

        # batch的上下界
        main.addConstr((z.sum() >= batch_lb), name='batch_lb')
        main.addConstr((z.sum() <= batch_ub), name='batch_ub')



        # 添加变量和约束后更新模型
        main.update()
        # main.setParam(GRB.Param.LogFile,f'15_L_{part_i}.log') # 设置日志文件

        main.Params.TimeLimit = 7200
        main.Params.MIPGap = 0

        # 启用 Lazy Constraints
        main.setParam(GRB.Param.LazyConstraints, 1)
        # 关联变量到 callback
        main._z = z
        main._u = u
        main._unassigned_subset_list_try = unassigned_subset_list_try # 传递到 callback 函数中

        MP_start_time = time.time()
        main.optimize(my_callback) # 添加回调函数

        num_MP_iteration += 1 # 每求解一次主问题就+1
        MP_end_time = time.time()
        # MP_total_time += (MP_end_time - MP_start_time)
        MP_runtime += main.Runtime
        run_time += main.Runtime



        # 输出主问题的解
        if main.Status == GRB.OPTIMAL: # 如果主问题optimal
            indicator_masterfeasible = 1 # 令主问题可行的indicator=1

            # 以写入模式（'w'）打开文件时，如果文件不存在，Python会自动创建该文件。
            # g = open('AM&OS/benders_iteration[%d].txt' %num_MP_iteration, 'w') # 这里用的是num_MP_iteration
            # for v in main.getVars():
            #     g.write(v.varName + ',' + str(v.x))
            #     g.write('\n')
            # g.write('Objective:' + str(main.ObjVal)) # 主问题的当前最优值
            # g.close()


            # ========================================
            # 读取主问题的解
            # ========================================
            # 创建保存主问题解的空列表
            z_solution = [0 for b in batch]
            u_solution = [[0 for b in batch] for i in part]
            h_solution = [0 for b in batch]
            C_solution = [0 for b in batch]
            makespan_solution = 0

            # 利用getVars读取变量数据
            for v in main.getVars():
                split_arr = re.split(r'[,\[\]]', v.VarName) # 将gurobi形式的变量进行拆解
                if split_arr[0] == 'z' and v.x != 0:
                    z_solution[int(split_arr[1])] = v.x
                elif split_arr[0] == 'u' and v.x != 0:
                    u_solution[int(split_arr[1])][int(split_arr[2])] = v.x
                elif split_arr[0] == 'h' and v.x != 0:
                    h_solution[int(split_arr[1])] = v.x
                elif split_arr[0] == 'C' and v.x != 0:
                    C_solution[int(split_arr[1])] = v.x
                elif split_arr[0] == 'C_makespan':
                    makespan_solution = v.x
                else:
                    pass
            # 读取主问题的解
            obj_solution = main.ObjVal
            obj_lowerbound = obj_solution # 把这个解作为下界，传递到主问题的约束里，限制一部分解空间（？）

            batch_lowerbound = int(sum(z_solution)) # 当前主问题解的batch数
            
            # 根据每次主问题的解，用assigned_b记录分配在batch b中的零件有哪些
            assigned_b = [[] for b in range(0, batch_lowerbound)]
            for b in range(0, batch_lowerbound):
                for i in part:
                    if u_solution[i][b] == 1:
                        assigned_b[b].append(i)

            # # 存储不能放到同一个batch里的零件集合（后续考虑占优情况）
            # unassigned_list = []

            # 用来表示每个batch的子问题是否infeasible，不可行=1，可行=0
            indicator_subeachinfeasible = [0 for _ in range(batch_lowerbound)]


            # ==========================================================
            # 针对每一个batch建立子问题模型 construct slave problem model
            # ==========================================================
            for b in range(0, batch_lowerbound): # 用batch_lowerbound是否比batch更好？
                if len(assigned_b[b]) <= 1: # 如果这个batch中零件数量小于等于1，直接跳过
                    indicator_subeachinfeasible[b] = 0
                    continue
                else:
                    # 理论上 assigned_b[b] 不可能包含任何 un，但以下代码是保险检查
                    # for un in unassigned_subset_list_try:
                    #     if set(un).issubset(set(assigned_b[b])): # batch中的零件组合不可行，已有不可行子集
                    #         print('sub batch%d is infeasible' %b)
                    #         indicator_subeachinfeasible[b] = 1
                    #         break
                    # else:

                    # ====================================================================
                    # 先通过Steinberg‘s Theorem来预判断assigned_b[b]是否可行，是否要计算子问题
                    # ====================================================================
                    idx_arr = np.array(assigned_b[b], dtype=int)
                    max_w = width_arr[idx_arr].max()
                    max_l = length_arr[idx_arr].max()
                    batch_area = area_arr[idx_arr].sum()

                    width_item = max(2*max_w - width_machine, 0)
                    length_item = max(2*max_l - length_machine, 0)
                    if (2*batch_area) <= (width_machine*length_machine - width_item*length_item):
                        # 如果满足，则认为可行，跳过子问题
                        # indicator_sbgfeasible = 1
                        continue

                    sub_each = Model('sub_each')

                    # 定义决策变量
                    x_each = sub_each.addVars(assigned_b[b], ub=width_machine, vtype=GRB.CONTINUOUS, name='x_each')
                    y_each = sub_each.addVars(assigned_b[b], ub=length_machine, vtype=GRB.CONTINUOUS, name='y_each')
                    left = sub_each.addVars(assigned_b[b], assigned_b[b], vtype=GRB.BINARY, name='left')
                    below = sub_each.addVars(assigned_b[b], assigned_b[b], vtype=GRB.BINARY, name='below')
                    # 这样可以保证变量的索引就是assigned_b[b]中零件的编号，不用再转换

                    # 定义目标函数
                    sub_each.setObjective(0, sense=GRB.MINIMIZE)

                    # 添加子问题的约束
                    # x[i] + w[i] <= W，i已经是零件编号了，不用再转换
                    sub_each.addConstrs((x_each[i] + width_part[i] <= width_machine for i in assigned_b[b]), name='3a')
                    # y[i] + l[i] <= L
                    sub_each.addConstrs((y_each[i] + length_part[i] <= length_machine for i in assigned_b[b]), name='3b')
                    # left_ij + left_ji + +below_ij + below_ji >= 1
                    for i in assigned_b[b]:
                        for j in assigned_b[b]:
                            if i != j:
                                sub_each.addConstr((left[i,j] + left[j,i] + below[i,j] + below[j,i] >= 1), name='3c[%d,%d]' %(i,j))
                    # x[i] + w[i] <= x[j] + W(1-left_ij)
                    for i in assigned_b[b]:
                        for j in assigned_b[b]:
                            if i != j:
                                sub_each.addConstr((x_each[i] + width_part[i] <= x_each[j] + width_machine*(1 - left[i,j])), name='3d[%d,%d]' %(i,j))
                    # y[i] + l[i] <= y[j] + L(1-below_ij)
                    for i in assigned_b[b]:
                        for j in assigned_b[b]:
                            if i != j:
                                sub_each.addConstr((y_each[i] + length_part[i] <= y_each[j] + length_machine*(1 - below[i,j])), name='3e[%d,%d]' %(i,j))

                    # 添加变量和约束后更新模型
                    sub_each.update()

                    sub_each.Params.TimeLimit = 1800
                    SP_start_time = time.time()
                    sub_each.optimize()

                    SP_end_time = time.time()
                    num_SP_iteration += 1 # 每求解一次子问题，就加1
                    SP_total_time += (SP_end_time - SP_start_time)
                    SP_runtime += sub_each.Runtime
                    run_time += sub_each.Runtime



                    if sub_each.Status == GRB.INFEASIBLE: # 如果对于这个batch，子问题不可行
                        print('sub batch%d is infeasible' %b)
                        indicator_subeachinfeasible[b] = 1
                        unassigned_subset_list_try.append(assigned_b[b])


                        # 如果这个子问题不可行，那么找这个assigned_b[b]中零件的MIS
                        assigned_subset_n_2 = list(combinations(assigned_b[b],2))  # 先将零件组合成两两组合的形式
                        for i in range(len(assigned_subset_n_2)):
                            assigned_subset_n_2[i] = list(assigned_subset_n_2[i]) # 把元组换成列表形式
                        
                        subset_templist = assigned_subset_n_2
                        infeasible_number_n = [0] * len(assigned_b[b]) # 储存一共有几组subset n   
                        SP_MIS_ban = [] # 储存寻找MIS过程中的不可行子集，避免重复                 
                        
                        for n in range(2, len(assigned_b[b])): # 对于assigned_mb[m][b]中每一个n进行循环,不用对n=N的循环了
                            if len(subset_templist) == 0:
                                break

                            MIS_feasible = [] #存储subset_templist中的可行子集
                            for assigned_subset in subset_templist: # subset_templist 表示这个n下的所有subset

                                flag_ban = 0
                                for ban in SP_MIS_ban:
                                    if set(assigned_subset)>=set(ban):
                                        flag_ban = 1
                                        break
                                if flag_ban:
                                    subset_templist.remove(assigned_subset)
                                    continue

                                # ====================================================================
                                # 先通过Steinberg‘s Theorem来预判断assigned_subset是否可行，是否要计算子问题
                                # ====================================================================
                                idx_arr = np.array(assigned_subset, dtype=int)
                                max_w = width_arr[idx_arr].max()
                                max_l = length_arr[idx_arr].max()
                                batch_area = area_arr[idx_arr].sum()

                                width_item = max(2*max_w - width_machine, 0)
                                length_item = max(2*max_l - length_machine, 0)
                                if (2*batch_area) <= (width_machine*length_machine - width_item*length_item):
                                    # 如果满足，则认为可行，跳过子问题
                                    # indicator_sbgfeasible = 1
                                    MIS_feasible.append(assigned_subset)
                                    continue

                                MIS_each = Model('MIS_each')

                                # 定义决策变量
                                x_each = MIS_each.addVars(assigned_subset, ub=width_machine, vtype=GRB.CONTINUOUS, name='x_each')
                                y_each = MIS_each.addVars(assigned_subset, ub=length_machine, vtype=GRB.CONTINUOUS, name='y_each')
                                left = MIS_each.addVars(assigned_subset, assigned_subset, vtype=GRB.BINARY, name='left')
                                below = MIS_each.addVars(assigned_subset, assigned_subset, vtype=GRB.BINARY, name='below')
                                # 这样可以保证变量的索引就是assigned_b[b]中零件的编号，不用再转换

                                # 定义目标函数
                                MIS_each.setObjective(0, sense=GRB.MINIMIZE)

                                # 添加子问题的约束
                                # x[i] + w[i] <= W，i已经是零件编号了，不用再转换
                                MIS_each.addConstrs((x_each[i] + width_part[i] <= width_machine for i in assigned_subset), name='3a')
                                # y[i] + l[i] <= L
                                MIS_each.addConstrs((y_each[i] + length_part[i] <= length_machine for i in assigned_subset), name='3b')
                                # left_ij + left_ji + +below_ij + below_ji >= 1
                                for i in assigned_subset:
                                    for j in assigned_subset:
                                        if i != j:
                                            MIS_each.addConstr((left[i,j] + left[j,i] + below[i,j] + below[j,i] >= 1), name='3c[%d,%d]' %(i,j))
                                # x[i] + w[i] <= x[j] + W(1-left_ij)
                                for i in assigned_subset:
                                    for j in assigned_subset:
                                        if i != j:
                                            MIS_each.addConstr((x_each[i] + width_part[i] <= x_each[j] + width_machine*(1 - left[i,j])), name='3d[%d,%d]' %(i,j))
                                # y[i] + l[i] <= y[j] + L(1-below_ij)
                                for i in assigned_subset:
                                    for j in assigned_subset:
                                        if i != j:
                                            MIS_each.addConstr((y_each[i] + length_part[i] <= y_each[j] + length_machine*(1 - below[i,j])), name='3e[%d,%d]' %(i,j))

                                # 添加变量和约束后更新模型
                                MIS_each.update()

                                MIS_each.Params.TimeLimit = 1800
                                MIS_each.optimize()

                                num_SP_iteration += 1 # 每求解一次子问题，就加1
                                SP_runtime += MIS_each.Runtime
                                run_time += MIS_each.Runtime

                                if MIS_each.Status == GRB.INFEASIBLE:   # 如果对于这个MP-subset子问题不可行
                                    print(f'MIS_sub_n={assigned_subset} is infeasible')
                                    infeasible_number_n[n] += 1 # 在这个n下的子问题不可行的数量加1
                                    SP_MIS_ban.append(assigned_subset)
                                    unassigned_subset_list_try.append(assigned_subset)

                                if MIS_each.Status == GRB.OPTIMAL: # 如果对于这个subset子问题可行，循环迭代下一个
                                    MIS_feasible.append(assigned_subset)
                                    continue

                            if infeasible_number_n[n] == len(subset_templist):
                                break

                            if n < len(assigned_b[b])-1:
                                subset_templist.clear()
                                for s in MIS_feasible:
                                    for i in assigned_b[b]:
                                        if i > max(s):
                                            s_temp = s+[i]
                                            subset_templist.append(s_temp)

                        # else:
                        #     if infeasible_number_n[len(assigned_b[b])-1] == 0:
                        #         unassigned_subset_list_try.append(assigned_b[b])


                    if sub_each.Status == GRB.OPTIMAL:
                        print('sub batch%d is optimal' %b)
                        indicator_subeachinfeasible[b] = 0
                        # sub_each.write('AM&OS/subproblem_batch[%d].lp' %b)

                        # 输出子问题的optimal解
                        # f = open('AM&OS/subproblem_batch[%d].txt' %b, 'w')
                        # for x in sub_each.getVars():
                        #     f.write('%s = ' %x)
                        #     f.write(str(x.X))
                        #     f.write('\n')
                        # f.close()

                    # sub_each.reset()

            # 用来判断是否所有子问题都feasible了，如果是，flag = 0.就可以终止循环了
            indicator_sum = 0
            for b in range(batch_lowerbound):
                indicator_sum += indicator_subeachinfeasible[b]

            if indicator_sum == 0:
                flag = 0
                end_time = time.time()
                # CPU_time = float((end_time - start_time)) CPU_time多计算了一些时间，不准确
                # run_time = MP_runtime + SP_runtime

                print('obj= %f' %obj_solution)
                print(assigned_b)
                print(f'MP:{num_MP_iteration}')
                print(f'SP:{num_SP_iteration}')
                # print(f'time:{CPU_time}')
                print(f'run_time:{run_time}')

                with open(output_file, 'a') as f:
                    f.write('\n')
                    f.write(f'obj={obj_solution:.2f}\n')
                    # f.write(f'makespan={makespan_solution:.2f}\n')
                    f.write(f'MP: {num_MP_iteration}\n')
                    f.write(f'SP: {num_SP_iteration}\n')
                    # f.write(f'time: {CPU_time}, ')
                    f.write(f'run time:{run_time:.2f}\n')
                    f.write(f'MP run time:{MP_runtime:.2f}\n')
                    f.write(f'SP run time:{SP_runtime:.2f}\n')
                    f.write(f'cuts:{len(unassigned_subset_list_try)}\n')
                    f.write('obj solution:'+ str(assigned_b))
                    f.write('\n')
            else:
                print('not all subproblems are feasible')

        else:
            print('the master problem is not optimal')



if __name__ == '__main__':
    output_file = '15-M-1_MIS+all_output.txt'
    # 读取所有算例
    for i in range(1, 11):
        csv_path = f'15/15parts_{i}.csv'
        print(f'Processing {csv_path}')
        run_model(csv_path, output_file, i)





