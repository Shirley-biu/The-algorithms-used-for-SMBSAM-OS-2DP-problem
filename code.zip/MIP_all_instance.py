'''
Create on 
@author: BI
'''

from gurobipy import *
import numpy as np
import pandas as pd
import re
import time
from fractions import Fraction

# 封装模型函数
def run_model(csv_path, output_file):

    # ===============================
    # 读取数据 read data
    # ===============================
    df = pd.read_csv(csv_path)

    #  机器加工的相关参数
    time_forming_volume = 0.030864 # 扫描速度
    time_powder_layering = 0.7 # 层构建速度
    setup_time = 2

    # 机器的长宽高 S
    length_machine = 15
    width_machine = 15
    height_machine = 32.5
    # M
    # length_machine = 17.5
    # width_machine = 17.5
    # height_machine = 32.5
    # L
    # length_machine = 20
    # width_machine = 20
    # height_machine = 32.5

    # 零件数量
    num_part = len(df)
    part = list(range(0,num_part))

    # batch数量，与part数量保持一致
    num_batch = num_part
    batch = list(range(0,num_batch))

    # 零件的长宽高
    length_part = df.length_part.tolist()
    width_part = df.width_part.tolist()
    height_part = df.height_part.tolist()
    volume_part = df.volume_part.tolist()

    # 客户相关参数
    num_customer = 3
    beta = 1
    customer = list(range(0,num_customer))
    order_part = df.customer.tolist()
    a = np.zeros((num_part, num_customer)) #零件i是否属于客户k
    for i in part:
        for k in customer:
            if order_part[i] == k:
                a[i][k] = 1 



    # ===============================================
    # 建立原问题模型 construct model
    # ===============================================
    CPU_time = 0
    start_time = time.time()

    main = Model('main')

    # 定义决策变量
    # 主问题的决策变量
    z = main.addVars(batch, vtype=GRB.BINARY, name='z')
    u = main.addVars(part, batch, vtype=GRB.BINARY, name='u')
    h = main.addVars(batch, ub=height_machine ,vtype=GRB.CONTINUOUS, name='h')
    C = main.addVars(batch, vtype=GRB.CONTINUOUS, name='C')
    C_makespan = main.addVar(vtype=GRB.CONTINUOUS, name='C_makespan')
    C_spread = main.addVars(customer, vtype=GRB.CONTINUOUS, name='C_spread')
    S_spread = main.addVars(customer, vtype=GRB.CONTINUOUS, name='S_spread')
    E_spread = main.addVars(customer, vtype=GRB.CONTINUOUS, name='E_spread')
    # 不包含在主问题中的变量
    left = main.addVars(part, part, batch, vtype=GRB.BINARY, name='left')
    below = main.addVars(part, part, batch, vtype=GRB.BINARY, name='below')
    x = main.addVars(part, vtype=GRB.CONTINUOUS, name='x')
    y = main.addVars(part, vtype=GRB.CONTINUOUS, name='y')


    # 定义目标函数
    main.setObjective(C_makespan + beta*C_spread.sum(), sense=GRB.MINIMIZE)

    # main.setObjective(C_makespan, sense=GRB.MINIMIZE)
    # main.setObjective(C_spread.sum(), sense=GRB.MINIMIZE)


    # 添加约束
    # 累加b的uib=1, for i
    main.addConstrs((u.sum(i, '*') == 1 for i in part), name='2b')
    # hi * uib <= hb
    main.addConstrs((height_part[i]*u[i,b] <= h[b] for i in part for b in batch), name='2c')
    # 累加i的uib <= M * zb
    main.addConstrs((u.sum('*', b) <= num_part * z[b] for b in batch), name='2d')
    # zb <= 累加i的uib
    main.addConstrs((z[b] <= u.sum('*', b) for b in batch), name='2e')
    # zb+1 <= zb
    main.addConstrs((z[b+1] <= z[b] for b in range(num_batch-1)), name='2f')
    # 累加i的wi*li*uib <= W*L
    # main.addConstrs((quicksum(width_part[i]*length_part[i]*u[i,b] for i in part) 
    #                 <= width_machine*length_machine for b in batch), name='2g')
    # Cb >= Cb-1 + VT*累加i的vi*uib + HT*hb + ST*zb
    main.addConstrs((C[b] >= C[b-1] + time_forming_volume*quicksum(volume_part[i]*u[i,b] for i in part) 
                    + time_powder_layering*h[b] + setup_time*z[b] for b in range(1, num_batch)), name='2h')
    # 初始化C0(可以改成等于吗？)
    main.addConstr((C[0] >= time_forming_volume*quicksum(volume_part[i]*u[i,0] for i in part) 
                    + time_powder_layering*h[0] + setup_time*z[0]), name='2i')
    # Cmax >= Cb
    main.addConstrs((C_makespan >= C[b] for b in batch), name='2j')
    # Sk <= 累加b的Cb*uib*aik
    # main.addConstrs((S_spread[k] <= quicksum(C[b]*u[i,b]*a[i][k] for b in batch) 
    #                 for i in part for k in customer), name='2k')
    main.addConstrs((S_spread[k] <= C[b] + 1000*(1-u[i,b]*a[i][k]) 
                    for i in part for b in batch for k in customer), name='2k')
    # Ek >= 累加b的Cb*uib*aik
    # main.addConstrs((E_spread[k] >= quicksum(C[b]*u[i,b]*a[i][k] for b in batch) 
    #                 for i in part for k in customer), name='2l')
    main.addConstrs((E_spread[k] >= C[b] - 1000*(1-u[i,b]*a[i][k])
                     for i in part for b in batch for k in customer), name='2l')
    # Ck = Ek - Sk
    main.addConstrs((C_spread[k] == E_spread[k]-S_spread[k] for k in customer), name='2m')

    # xi + wi <= W + M(1-uib)
    main.addConstrs((x[i] + width_part[i] <= width_machine + width_machine*(1-u[i,b]) for i in part for b in batch), name='1n')
    # yi + li <= L + M(1-uib)
    main.addConstrs((y[i] + length_part[i] <= length_machine + length_machine*(1-u[i,b]) for i in part for b in batch), name='1o')
    # left_ijb + left_jib + below_ijb + below_jib >= uib + ujb - 1
    for i in part:
        for j in part:
            if i != j:
                for b in batch:
                    main.addConstr((left[i,j,b] + left[j,i,b] + below[i,j,b] + below[j,i,b] >= u[i,b] + u[j,b] - 1),name='1p')
    # xi + wi <= xj + M(1-left_ijb)
    for i in part:
        for j in part:
            if i != j:
                for b in batch:
                    main.addConstr((x[i] + width_part[i] <= x[j] + width_machine*(1 - left[i,j,b])),name='1q')
    # yi + li <= yj + M(1-below_ijb)
    for i in part:
        for j in part:
            if i != j:
                for b in batch:
                    main.addConstr((y[i] + length_part[i] <= y[j] + length_machine*(1 - below[i,j,b])),name='1r')



    # 添加变量和约束后更新模型
    main.update()
    # 设置参数
    main.Params.TimeLimit = 7200
    main.Params.MIPGap = 0
    # 求解问题
    main.optimize()

    end_time = time.time()
    CPU_time = end_time - start_time

    # 输出问题的解
    with open(output_file, 'a') as f:
        f.write(f'Processing {csv_path}===========================\n')
        if main.Status == GRB.OPTIMAL: # 如果问题optimal
            f.write(f'optimal objective value={main.ObjVal:.2f}\n')
            # f.write(f'CPU time={CPU_time:.2F}\n') # 输出运行时间
            f.write(f'run time={main.Runtime:.2f}\n') # 输出运行时间
        elif main.Status == GRB.TIME_LIMIT:
            # 可行解
            if main.SolCount > 0:
                f.write('Reached time limit.\n')
                f.write(f'best feasible solution={main.ObjVal:.2f}\n')
                f.write(f'best bound={main.ObjBound:.2f}\n')
                gap = (main.ObjVal - main.ObjBound)/main.ObjVal
                f.write(f'MIP gap={gap*100:.2f}%\n')
                f.write(f'run time:{main.Runtime:.2f}\n') # 输出运行时间
            else:
                f.write('Reached time limit, but no solution found.')

# ==============================
# 主程序循环处理所有算例
# ==============================
if __name__ == '__main__':
    output_file = '20-S-1_mip_output.txt'
    # 读取所有算例
    for i in range(1, 11):
        csv_path = f'20/20parts_{i}.csv'
        print(f'Processing {csv_path}')
        run_model(csv_path, output_file)
