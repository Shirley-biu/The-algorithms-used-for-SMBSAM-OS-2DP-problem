import copy
import pandas as pd
import numpy as np
import time
import random

# ====================================
# Bottom-Left-Fill 启发式放置函数
# ====================================
def is_valid_position(placed_parts, new_part, x, y, width_machine, length_machine):
    if x + new_part["width"] > width_machine or y + new_part["length"] > length_machine:
        return False
    for p in placed_parts:
        if not (x + new_part["width"] <= p["x"] or 
                p["x"] + p["width"] <= x or 
                y + new_part["length"] <= p["y"] or 
                p["y"] + p["length"] <= y):
            return False
    return True

def slide_to_bottom_left(placed_parts, new_part, x, y, width_machine, length_machine):
    while True:
        moved = False
        while y > 0 and is_valid_position(placed_parts, new_part, x, y - 1, width_machine, length_machine):
            y -= 1
            moved = True
        while x > 0 and is_valid_position(placed_parts, new_part, x - 1, y, width_machine, length_machine):
            x -= 1
            moved = True
        if not moved:
            break
    return (x, y)

def bottom_left_fill_placement(placed_parts, new_part, width_machine, length_machine):
    if not placed_parts:
        if new_part["width"] <= width_machine and new_part["length"] <= length_machine:
            return (0, 0)
        else:
            return None
    candidates = set()
    candidates.add((0, 0))
    for p in placed_parts:
        candidates.add((p["x"] + p["width"], p["y"]))
        candidates.add((p["x"], p["y"] + p["length"]))
    cand_list = sorted(list(candidates), key=lambda pos: (pos[1], pos[0]))
    for (cx, cy) in cand_list:
        filled_x, filled_y = slide_to_bottom_left(placed_parts, new_part, cx, cy, width_machine, length_machine)
        if is_valid_position(placed_parts, new_part, filled_x, filled_y, width_machine, length_machine):
            return (filled_x, filled_y)
    return None

# ====================================
# 算法1：先按客户编号升序、客户内按高度降序
# ====================================
def algorithm1(parts, width_machine, length_machine, time_forming_volume, time_powder_layering, setup_time, beta):
    parts_alg = [p.copy() for p in parts]
    sorted_parts = sorted(parts_alg, key=lambda p: (p["customer"], -p["height"]))
    batches = []
    for p in sorted_parts:
        placed = False
        if batches:
            current_batch = batches[-1]
            pos = bottom_left_fill_placement(current_batch["parts"], p, width_machine, length_machine)
            if pos is not None:
                p["x"], p["y"] = pos
                p["batch"] = len(batches) - 1
                current_batch["parts"].append(p)
                placed = True
        if not placed:
            candidate_batches = [b for b in batches if any(q["customer"] == p["customer"] for q in b["parts"])]
            for b in candidate_batches:
                pos = bottom_left_fill_placement(b["parts"], p, width_machine, length_machine)
                if pos is not None:
                    p["x"], p["y"] = pos
                    p["batch"] = batches.index(b)
                    b["parts"].append(p)
                    placed = True
                    break
        if not placed:
            for b in batches:
                pos = bottom_left_fill_placement(b["parts"], p, width_machine, length_machine)
                if pos is not None:
                    p["x"], p["y"] = pos
                    p["batch"] = batches.index(b)
                    b["parts"].append(p)
                    placed = True
                    break
        if not placed:
            new_batch = {"parts": []}
            pos = bottom_left_fill_placement(new_batch["parts"], p, width_machine, length_machine)
            if pos is None:
                raise ValueError(f"零件 {p['id']} 即使在新批次也无法放置！")
            p["x"], p["y"] = pos
            p["batch"] = len(batches)
            new_batch["parts"].append(p)
            batches.append(new_batch)
    C = []
    for i, b in enumerate(batches):
        total_volume = sum(q["volume"] for q in b["parts"])
        max_height = max(q["height"] for q in b["parts"])
        proc_time = time_forming_volume * total_volume + time_powder_layering * max_height + setup_time
        if i == 0:
            C.append(proc_time)
        else:
            C.append(C[i-1] + proc_time)
        b["completion_time"] = C[i]
    makespan = C[-1]
    customer_times = {}
    for p in parts_alg:
        cust = p["customer"]
        part_completion_time = C[p["batch"]]
        if cust not in customer_times:
            customer_times[cust] = []
        customer_times[cust].append(part_completion_time)
    C_spread_sum = 0
    for cust, times in customer_times.items():
        spread = max(times) - min(times)
        C_spread_sum += spread
    objective = makespan + beta * C_spread_sum
    return batches, makespan, objective, sorted_parts

# ====================================
# 算法2：先按高度降序；放置时先检查同客户批次，再检查其他批次
# ====================================
def algorithm2(parts, width_machine, length_machine, time_forming_volume, time_powder_layering, setup_time, beta):
    parts_alg = [p.copy() for p in parts]
    sorted_parts = sorted(parts_alg, key=lambda p: -p["height"])
    batches = []
    for p in sorted_parts:
        placed = False
        candidate_batches = [b for b in batches if any(q["customer"] == p["customer"] for q in b["parts"])]
        for b in candidate_batches:
            pos = bottom_left_fill_placement(b["parts"], p, width_machine, length_machine)
            if pos is not None:
                p["x"], p["y"] = pos
                p["batch"] = batches.index(b)
                b["parts"].append(p)
                placed = True
                break
        if not placed:
            other_batches = [b for b in batches if not any(q["customer"] == p["customer"] for q in b["parts"])]
            for b in other_batches:
                pos = bottom_left_fill_placement(b["parts"], p, width_machine, length_machine)
                if pos is not None:
                    p["x"], p["y"] = pos
                    p["batch"] = batches.index(b)
                    b["parts"].append(p)
                    placed = True
                    break
        if not placed:
            new_batch = {"parts": []}
            pos = bottom_left_fill_placement(new_batch["parts"], p, width_machine, length_machine)
            if pos is None:
                raise ValueError(f"零件 {p['id']} 在新批次中无法放置！")
            p["x"], p["y"] = pos
            p["batch"] = len(batches)
            new_batch["parts"].append(p)
            batches.append(new_batch)
    C = []
    for i, b in enumerate(batches):
        total_volume = sum(q["volume"] for q in b["parts"])
        max_height = max(q["height"] for q in b["parts"])
        proc_time = time_forming_volume * total_volume + time_powder_layering * max_height + setup_time
        if i == 0:
            C.append(proc_time)
        else:
            C.append(C[i-1] + proc_time)
        b["completion_time"] = C[i]
    makespan = C[-1]
    customer_times = {}
    for p in parts_alg:
        cust = p["customer"]
        part_completion_time = C[p["batch"]]
        if cust not in customer_times:
            customer_times[cust] = []
        customer_times[cust].append(part_completion_time)
    C_spread_sum = 0
    for cust, times in customer_times.items():
        spread = max(times) - min(times)
        C_spread_sum += spread
    objective = makespan + beta * C_spread_sum
    return batches, makespan, objective, sorted_parts 

# ===============================
# 解评价函数：重新放置并计算目标函数值
# ===============================
def evaluate_solution(batches):
    new_batches = []
    for b in batches:
        new_b = {"parts": []}
        placed_parts = []
        # sorted_parts = sorted(b["parts"],
        #                       key=lambda p: p["width"]*p["length"],
        #                       reverse=True)

        for p in b["parts"]:
        # for p in sorted_parts:
            part_copy = p.copy()
            pos = bottom_left_fill_placement(placed_parts, part_copy, width_machine, length_machine)
            if pos is None:
                return None
            part_copy["x"], part_copy["y"] = pos
            placed_parts.append(part_copy)
        new_b["parts"] = placed_parts
        new_batches.append(new_b)
    C = []
    for i, b in enumerate(new_batches):
        total_volume = sum(q["volume"] for q in b["parts"])
        max_height = max(q["height"] for q in b["parts"]) if b["parts"] else 0
        proc_time = time_forming_volume * total_volume + time_powder_layering * max_height + setup_time
        if i == 0:
            C.append(proc_time)
        else:
            C.append(C[i-1] + proc_time)
        b["completion_time"] = C[i]
    makespan = C[-1] if C else 0
    customer_times = {}
    for b in new_batches:
        for p in b["parts"]:
            cust = p["customer"]
            part_completion_time = b["completion_time"]
            if cust not in customer_times:
                customer_times[cust] = []
            customer_times[cust].append(part_completion_time)
    C_spread_sum = 0
    for times in customer_times.values():
        spread = max(times) - min(times)
        C_spread_sum += spread
    obj = makespan + beta * C_spread_sum
    return new_batches, makespan, obj


# ===============================
# 辅助函数：深拷贝解
# ===============================
def copy_solution(batches):
    return copy.deepcopy(batches)

def diversify_solution(batches, k=3):
    sol = copy_solution(batches)
    all_parts = [(bi, p) for bi,b in enumerate(sol) for p in b["parts"]]
    picks = random.sample(all_parts, k)
    for bi, part in picks:
        # 随机选一个不同的批次 bj
        bj = random.choice([i for i in range(len(sol)) if i!=bi])
        sol[bi]["parts"].remove(part)
        sol[bj]["parts"].append(part)
    return sol

# ===============================
# 禁忌搜索算法（扩展领域操作，修正 move 中列表为元组）
# ===============================
def tabu_search(initial_batches, max_iter, tabu_tenure, max_no_improve):
    current_solution = copy_solution(initial_batches)
    eval_result = evaluate_solution(current_solution)
    if eval_result is None:
        print("初始解不可行！")
        return current_solution, float('inf')
    current_batches, current_makespan, current_obj = eval_result
    best_solution = copy_solution(current_batches)
    best_obj = current_obj
    tabu_list = {}  # 记录禁忌操作及其到期迭代数
    no_improve_count = 0  # 连续未改进计数


    for iter in range(max_iter):
        neighbors = []
        moves = []
        # 1. 重定位操作：单个零件移动
        for bi, batch in enumerate(current_solution):
            for part in batch["parts"]:
                for bj in range(len(current_solution)):
                    if bj == bi:
                        continue
                    if any(p["customer"] == part["customer"] for p in current_solution[bj]["parts"]):
                        move = ("relocate", part["id"], bi, bj)
                        new_solution = copy_solution(current_solution)
                        part_moved = None
                        for p in new_solution[bi]["parts"]:
                            if p["id"] == part["id"]:
                                part_moved = p
                                break
                        if part_moved is None:
                            continue
                        new_solution[bi]["parts"].remove(part_moved)
                        pos = bottom_left_fill_placement(new_solution[bj]["parts"], part_moved, width_machine, length_machine)
                        if pos is not None:
                            part_moved["x"], part_moved["y"] = pos
                            new_solution[bj]["parts"].append(part_moved)
                            neighbors.append(new_solution)
                            moves.append(move)
        # 1.1 重定位操作扩展：同时移动一对零件（将列表转换为元组）
        for bi, batch in enumerate(current_solution):
            if len(batch["parts"]) >= 2:
                for i in range(len(batch["parts"])):
                    for j in range(i+1, len(batch["parts"])):
                        parts_to_move = [batch["parts"][i], batch["parts"][j]]
                        for bj in range(len(current_solution)):
                            if bj == bi:
                                continue
                            if any(p["customer"] in [parts_to_move[0]["customer"], parts_to_move[1]["customer"]] for p in current_solution[bj]["parts"]):
                                move = ("relocate_multi", (parts_to_move[0]["id"], parts_to_move[1]["id"]), bi, bj)
                                new_solution = copy_solution(current_solution)
                                parts_removed = []
                                for part in parts_to_move:
                                    for p in new_solution[bi]["parts"]:
                                        if p["id"] == part["id"]:
                                            parts_removed.append(p)
                                            break
                                for p in parts_removed:
                                    new_solution[bi]["parts"].remove(p)
                                feasible = True
                                for p in parts_removed:
                                    pos = bottom_left_fill_placement(new_solution[bj]["parts"], p, width_machine, length_machine)
                                    if pos is None:
                                        feasible = False
                                        break
                                    else:
                                        p["x"], p["y"] = pos
                                        new_solution[bj]["parts"].append(p)
                                if feasible:
                                    neighbors.append(new_solution)
                                    moves.append(move)
        # 2. 交换操作：交换不同批次间的零件（单个及多零件组合）
        for bi in range(len(current_solution)):
            for bj in range(bi+1, len(current_solution)):
                for part_i in current_solution[bi]["parts"]:
                    for part_j in current_solution[bj]["parts"]:
                        move = ("exchange", part_i["id"], bi, part_j["id"], bj)
                        new_solution = copy_solution(current_solution)
                        part_i_new = None
                        part_j_new = None
                        for p in new_solution[bi]["parts"]:
                            if p["id"] == part_i["id"]:
                                part_i_new = p
                                break
                        for p in new_solution[bj]["parts"]:
                            if p["id"] == part_j["id"]:
                                part_j_new = p
                                break
                        if part_i_new is None or part_j_new is None:
                            continue
                        new_solution[bi]["parts"].remove(part_i_new)
                        new_solution[bj]["parts"].remove(part_j_new)
                        pos_i = bottom_left_fill_placement(new_solution[bj]["parts"], part_i_new, width_machine, length_machine)
                        pos_j = bottom_left_fill_placement(new_solution[bi]["parts"], part_j_new, width_machine, length_machine)
                        if pos_i is not None and pos_j is not None:
                            part_i_new["x"], part_i_new["y"] = pos_i
                            part_j_new["x"], part_j_new["y"] = pos_j
                            new_solution[bj]["parts"].append(part_i_new)
                            new_solution[bi]["parts"].append(part_j_new)
                            neighbors.append(new_solution)
                            moves.append(move)
                # 多零件交换：交换两对零件（列表转换为元组）
                if len(current_solution[bi]["parts"]) >= 2 and len(current_solution[bj]["parts"]) >= 2:
                    for i in range(len(current_solution[bi]["parts"])):
                        for j in range(i+1, len(current_solution[bi]["parts"])):
                            for m in range(len(current_solution[bj]["parts"])):
                                for n in range(m+1, len(current_solution[bj]["parts"])):
                                    move = ("exchange_multi", 
                                            (current_solution[bi]["parts"][i]["id"], current_solution[bi]["parts"][j]["id"]),
                                            bi,
                                            (current_solution[bj]["parts"][m]["id"], current_solution[bj]["parts"][n]["id"]),
                                            bj)
                                    new_solution = copy_solution(current_solution)
                                    parts_i = []
                                    for p in new_solution[bi]["parts"]:
                                        if p["id"] in (current_solution[bi]["parts"][i]["id"], current_solution[bi]["parts"][j]["id"]):
                                            parts_i.append(p)
                                    parts_j = []
                                    for p in new_solution[bj]["parts"]:
                                        if p["id"] in (current_solution[bj]["parts"][m]["id"], current_solution[bj]["parts"][n]["id"]):
                                            parts_j.append(p)
                                    for p in parts_i:
                                        new_solution[bi]["parts"].remove(p)
                                    for p in parts_j:
                                        new_solution[bj]["parts"].remove(p)
                                    feasible = True
                                    for p in parts_i:
                                        pos = bottom_left_fill_placement(new_solution[bj]["parts"], p, width_machine, length_machine)
                                        if pos is None:
                                            feasible = False
                                            break
                                        else:
                                            p["x"], p["y"] = pos
                                            new_solution[bj]["parts"].append(p)
                                    if not feasible:
                                        continue
                                    for p in parts_j:
                                        pos = bottom_left_fill_placement(new_solution[bi]["parts"], p, width_machine, length_machine)
                                        if pos is None:
                                            feasible = False
                                            break
                                        else:
                                            p["x"], p["y"] = pos
                                            new_solution[bi]["parts"].append(p)
                                    if feasible:
                                        neighbors.append(new_solution)
                                        moves.append(move)
        # 2.1 批次顺序交换操作
        for bi in range(len(current_solution)):
            for bj in range(bi+1, len(current_solution)):
                move = ("exchange_batch_order", bi, bj)
                new_solution = copy_solution(current_solution)
                new_solution[bi], new_solution[bj] = new_solution[bj], new_solution[bi]
                for index, batch in enumerate(new_solution):
                    for p in batch["parts"]:
                        p["batch"] = index
                neighbors.append(new_solution)
                moves.append(move)
        # 3. 合并操作：合并零件较少或加工时间较短的批次
        batch_proc_times = []
        for b in current_solution:
            if len(b["parts"]) > 0:
                total_volume = sum(p["volume"] for p in b["parts"])
                max_height = max(p["height"] for p in b["parts"])
                proc_time = time_forming_volume * total_volume + time_powder_layering * max_height + setup_time
            else:
                proc_time = float('inf')
            batch_proc_times.append(proc_time)
        avg_proc_time = np.mean(batch_proc_times) if batch_proc_times else 0
        for bi in range(len(current_solution)):
            if len(current_solution[bi]["parts"]) <= 2 or (batch_proc_times[bi] < 0.8 * avg_proc_time):
                if bi > 0:
                    move = ("merge", bi, bi-1)
                    new_solution = copy_solution(current_solution)
                    new_solution[bi-1]["parts"].extend(new_solution[bi]["parts"])
                    del new_solution[bi]
                    neighbors.append(new_solution)
                    moves.append(move)
                if bi < len(current_solution) - 1:
                    move = ("merge", bi, bi+1)
                    new_solution = copy_solution(current_solution)
                    new_solution[bi+1]["parts"].extend(new_solution[bi]["parts"])
                    del new_solution[bi]
                    neighbors.append(new_solution)
                    moves.append(move)
        # 4. 拆分操作：拆分过于“拥挤”的批次
        for bi in range(len(current_solution)):
            if len(current_solution[bi]["parts"]) >= 4:
                for part in current_solution[bi]["parts"]:
                    move = ("split", part["id"], bi)
                    new_solution = copy_solution(current_solution)
                    part_to_split = None
                    for p in new_solution[bi]["parts"]:
                        if p["id"] == part["id"]:
                            part_to_split = p
                            break
                    if part_to_split is None:
                        continue
                    new_solution[bi]["parts"].remove(part_to_split)
                    new_batch = {"parts": [part_to_split]}
                    new_solution.insert(bi+1, new_batch)
                    neighbors.append(new_solution)
                    moves.append(move)
        # 4.1 拆分操作扩展：拆分多个零件（转换为元组）
        for bi in range(len(current_solution)):
            if len(current_solution[bi]["parts"]) >= 5:
                for i in range(len(current_solution[bi]["parts"])):
                    for j in range(i+1, len(current_solution[bi]["parts"])):
                        move = ("split_multi", (current_solution[bi]["parts"][i]["id"], current_solution[bi]["parts"][j]["id"]), bi)
                        new_solution = copy_solution(current_solution)
                        parts_to_split = []
                        for p in new_solution[bi]["parts"]:
                            if p["id"] in (current_solution[bi]["parts"][i]["id"], current_solution[bi]["parts"][j]["id"]):
                                parts_to_split.append(p)
                        for p in parts_to_split:
                            new_solution[bi]["parts"].remove(p)
                        new_batch = {"parts": parts_to_split}
                        new_solution.insert(bi+1, new_batch)
                        neighbors.append(new_solution)
                        moves.append(move)
        # 选择最优邻域解
        best_neighbor = None
        best_neighbor_obj = float('inf')
        best_move = None
        for sol, move in zip(neighbors, moves):
            if move in tabu_list and tabu_list[move] > iter:
                eval_result = evaluate_solution(sol)
                if eval_result is None:
                    continue
                _, _, sol_obj = eval_result
                # 破禁：只有当邻域解比当前全局最优好时才考虑
                if sol_obj < best_obj and sol_obj < best_neighbor_obj:
                    best_neighbor = sol
                    best_neighbor_obj = sol_obj
                    best_move = move
            else:
                eval_result = evaluate_solution(sol)
                if eval_result is None:
                    continue
                _, _, sol_obj = eval_result
                if sol_obj < best_neighbor_obj:
                    best_neighbor = sol
                    best_neighbor_obj = sol_obj
                    best_move = move

        if best_neighbor is None:
            print("迭代 {} 时无改进邻域，终止搜索".format(iter))
            break
        min_tenure = 5
        max_tenure = 10
        # 判断是否改进了全局最佳解
        if best_neighbor_obj < best_obj:
            # 更新全局最优
            sorted_batches, _, _ = evaluate_solution(best_neighbor)
            best_solution = copy_solution(sorted_batches)
            best_obj = best_neighbor_obj
            no_improve_count = 0
            # tabu_tenure = max(min_tenure, tabu_tenure-random.randint(0,1))

        else:
            no_improve_count += 1
            # if no_improve_count % 5 == 0:
            #     tabu_tenure = min(max_tenure, tabu_tenure+random.randint(0,1))

        
        # 如果连续多次未改进，则终止搜索
        # if no_improve_count >= max_no_improve:
        #     print("连续 {} 次迭代未改进最佳解，终止搜索".format(max_no_improve))
        #     break

        if no_improve_count >= max_no_improve:
            print("触发多样化扰动")
            current_solution = diversify_solution(best_solution, k=3)
            no_improve_count = 0
            continue

        
        # 每次都把 current_solution 换成评价后的重排版本
        # sorted_batches, _, _ = evaluate_solution(best_neighbor)
        # current_solution = copy_solution(sorted_batches)

        current_solution = best_neighbor
        tabu_list[best_move] = iter + tabu_tenure
        print("迭代 {}: 当前最佳目标函数值 = {:.2f}".format(iter, best_neighbor_obj))
    return best_solution, best_obj, iter+1

# ===============================
# 主程序：先用初始解算法，再用禁忌搜索优化
# ===============================
if __name__ == "__main__":
    # 机器加工的相关参数
    time_forming_volume = 0.030864  # 扫描速度
    time_powder_layering = 0.7      # 层构建速度
    setup_time = 2

    # 机器的长宽高
    # S
    length_machine = 15
    width_machine = 15
    height_machine = 32.5
    # M
    # length_machine = 17.5
    # width_machine = 17.5
    # height_machine = 32.5
    # L
    # length_machine = 20
    # width_machine = 20
    # height_machine = 32.5

    # 客户相关参数
    num_customer = 3
    beta = 1  # 可以调整

    output_file = 'blf_15-S-1-1072.txt'

    for id in range(1, 11):
        print(f"\n========== 运行 parts_{id} ==========")
        # 读取对应的数据
        df = pd.read_csv(f'15/15parts_{id}.csv')
        
        # 更新零件信息
        num_part = len(df)
        length_part = df.length_part.tolist()
        width_part = df.width_part.tolist()
        height_part = df.height_part.tolist()
        volume_part = df.volume_part.tolist()
        order_part = df.customer.tolist()

        parts = []
        for i in range(num_part):
            parts.append({
                "id": i,
                "customer": order_part[i],
                "width": width_part[i],
                "length": length_part[i],
                "height": height_part[i],
                "volume": volume_part[i],
                "x": None,
                "y": None,
                "batch": None
            })
        # print("========== initial solution ==========")
        batches, makespan, obj, parts_sorted = algorithm1(parts, width_machine, length_machine, 
                                                        time_forming_volume, time_powder_layering, setup_time, beta)
        # print(f"batch = {len(batches)}")
        # for idx, b in enumerate(batches):
        #     part_ids = [p["id"] for p in b["parts"]]
            # print(f" batch {idx}: part {part_ids}, completion time {b['completion_time']:.2f}")
        # print(f"obj = {obj:.2f}")
        
        print("\n========== Tabu Search ==========")
        start_time = time.time()
        best_batches, best_obj, actual_iter = tabu_search(batches, max_iter=10*num_part, tabu_tenure=7, max_no_improve=2*num_part)
        end_time = time.time()
        print(f"run time：{end_time - start_time:.2f}")
        eval_result = evaluate_solution(best_batches)
        if eval_result is not None:
            best_batches, best_makespan, best_obj = eval_result
            print(f"obj = {best_obj:.2f}")
            print(f"batch = {len(best_batches)}")
            # for idx, b in enumerate(best_batches):
            #     part_ids = [p["id"] for p in b["parts"]]
            #     print(f" batch {idx}: part {part_ids}, completion time {b['completion_time']:.2f}")
        else:
            print("the solution is not feasible!")
        with open(output_file, 'a', encoding='utf-8-sig') as f:
            f.write(f'parts_{id} solution========================\n')
            f.write(f'obj = {best_obj:.2f}\n')
            f.write(f'run time：{end_time - start_time:.2f}\n')
            f.write(f'iteration：{actual_iter}\n')
            


            


